package utils;

import com.core.Grocery;
import custom_exception.GroceryHandlingException;

import java.time.LocalDate;
import java.util.List;

public class GroceryValidationRules {

    public static void checkDuplicate(String name, List<Grocery> groceries) throws GroceryHandlingException
    {
        Grocery grocery=new Grocery(name);
        if(groceries.contains(grocery))
        {
            throw new GroceryHandlingException("Item already present...Duplicate Item Entered..");
        }
        System.out.println("Valid Item...");
    }

    public  static LocalDate parseDateAndTime(String dateAndTime)
    {
        return LocalDate.parse(dateAndTime);
    }

    public static Grocery validateAllInput(String name, int price, int qty, String stockUpdate,List<Grocery> groceries) throws GroceryHandlingException {
        LocalDate dateTime=parseDateAndTime(stockUpdate);
        checkDuplicate(name,groceries);
        return new Grocery(name,price,qty,dateTime);
    }
}
