package utils;

import com.core.Grocery;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class PopulateData {
    public static ArrayList<Grocery> populateData()
    {
        ArrayList<Grocery> groceries=new ArrayList<>();

        groceries.add(new Grocery("Potato",20,0, LocalDate.parse("2021-09-11")));
        groceries.add(new Grocery("Onions",30,3, LocalDate.parse("2022-11-27")));
        groceries.add(new Grocery("Tomato",35,6, LocalDate.parse("2020-05-01")));
        groceries.add(new Grocery("Cucumber",15,3, LocalDate.parse("2019-10-08")));
        groceries.add(new Grocery("Coriander",10,0, LocalDate.parse("2023-10-24")));

        return groceries;
    }

}
