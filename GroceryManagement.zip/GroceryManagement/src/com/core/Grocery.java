package com.core;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Grocery {
    private String name;
    private int price;
    private int qty;
    private LocalDate stockUpdate;

    public Grocery(String name, int price, int qty, LocalDate stockUpdate) {
        this.name = name;
        this.price = price;
        this.qty = qty;
        this.stockUpdate = stockUpdate;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public LocalDate getStockUpdate() {
        return stockUpdate;
    }

    public void setStockUpdate(LocalDate stockUpdate) {
        this.stockUpdate = stockUpdate;
    }

    public Grocery(String name)
    {
        this.name=name;
    }
    @Override
    public boolean equals(Object o)
    {
        Grocery grocery =(Grocery) o;
        return this.name.equals(grocery.name);
    }

    @Override
    public String toString() {
        return "Grocery{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", qty=" + qty +
                ", stockUpdate=" + stockUpdate +
                '}';
    }
}
