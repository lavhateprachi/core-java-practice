import com.core.Grocery;
import utils.GroceryValidationRules;
import utils.PopulateData;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<Grocery> groceries = new ArrayList<>();
        boolean exit=false;

        try(Scanner sc = new Scanner(System.in))
        {
            groceries = PopulateData.populateData();
            while (!exit) {
                System.out.println("Options: \n1.Add Item" +
                        "\n2.Update Quantity" +
                        "\n3.Display Grocery Items" +
                        "\n4.Remove All Empty Stocks" +
                        "\n5.Display Items Updated in Last 3 Days" +
                        "\n0.Exit");

                System.out.println("Select Option:");
                try
                {
                    switch (sc.nextInt()) {
                        case 1:
                            System.out.println("Enter Name | Price | Quantity | StockUpdateDateTime");
                            Grocery grocery = GroceryValidationRules.validateAllInput(sc.next(), sc.nextInt(), sc.nextInt(), sc.next(), groceries);
                            groceries.add(grocery);
                            System.out.println("Item inserted successfully...");
                            break;

                        case 2:
                            System.out.println("Enter GroceryName and Quantity: ");
                            String name=sc.next();
                            int qty=sc.nextInt();

                            groceries.stream().filter(grocery1 -> grocery1.getName().equals(name)).forEach(grocery1 -> {
                                grocery1.setQty(grocery1.getQty()+qty);

                                System.out.println("Updated Quantity: "+grocery1.getQty());
                            });
                            break;
                        case 3:
                            groceries.forEach(grocery1 -> System.out.println(grocery1));
                            break;

                        case 4:
                            Iterator<Grocery> itr=groceries.iterator();
                            while (itr.hasNext())
                            {
                                Grocery gr = itr.next();
                                if(gr.getQty()==0)
                                {
                                    itr.remove();
                                    System.out.println("Removed Item: "+gr.getName()+"\nQuantity: "+gr.getQty());
                                }
                            }

                            break;
                        case 5:
                           for(Grocery grocery1:groceries)
                           {
                                Period period=Period.between(grocery1.getStockUpdate(),LocalDate.now());
                                int days=period.getDays();
                                if(days<=3)
                                {
                                    System.out.println("Grocery Item Name: "+grocery1.getName());
                                    System.out.println(grocery1);
                                }
                            }
                            break;
                        case 0:
                            exit=true;
                            break;

                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }

    }
}