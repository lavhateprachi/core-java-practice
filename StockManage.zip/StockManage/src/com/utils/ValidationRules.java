package com.utils;

import java.time.LocalDate;
import java.util.List;

import com.core.Stock;

import custom_exception.StockHandlingException;

public class ValidationRules {
	
	public static void checkDup(String name,List<Stock> stock) throws StockHandlingException
	{
		Stock s = new Stock(name);
		if(stock.contains(s))
		{
			throw new StockHandlingException("Duplicate Data ...");
		}
		System.out.println("No duplicate data...");
	}
	public static void checkStocks(int id,int qty,List<Stock> stock) throws StockHandlingException
	{
		Stock s = new Stock(id);
		if(!stock.contains(s))
		{
			throw new StockHandlingException("Invalid id...");
		}
		else
		{
			if(s.getStockId()==id) {
				if (s.getQty() < qty) {
					throw new StockHandlingException("Insufficient Stocks...");
				} else {
					s.setQty(s.getQty() - qty);
					System.out.println("Id: " + s.getStockId() + "Updated(Purchase) Stocks: " + s.getQty());
				}
			}
			
		}
	}
	
	public static LocalDate parseandValidate(String date)
	{
		return LocalDate.parse(date);
		
	}
	
	public static Stock validateInput(String stockName, String companyName, double price, String closingDate, int qty,List<Stock> stock) throws StockHandlingException
	{
		checkDup(stockName,stock);
		LocalDate parseDate=parseandValidate(closingDate);
		return new Stock(stockName,companyName,price,parseDate,qty);
		
	}
	

}
