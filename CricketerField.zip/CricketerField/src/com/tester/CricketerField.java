package com.tester;

import java.util.ArrayList;
import java.util.Scanner;
import utils.*;
import com.core.*;

public class CricketerField {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Scanner sc = new Scanner(System.in))
		{
			ArrayList<Cricketer> list = new ArrayList<>();
			while(true)
			{
				System.out.println("Option: \n1.Add Cricketer Data"
						+ "\n2.Modify Rating"
						+ "\n3.Search By Name"
						+ "\n4.Display"
						+ "\n5.Sort by Rating"
						+ "\n0.Exit");
				
				System.out.println("Enter Choice: ");
				switch (sc.nextInt()) {
				case 1:
					System.out.println("Enter name,age,email,phone,rating:");
					Cricketer c = ValidationRules.validateAllInput(sc.next(), sc.nextInt(),
							sc.next(), sc.next(), sc.nextInt());
					
					list.add(c);
					System.out.println("data added successfully...");
					break;
				case 0:
					System.exit(0);
					break;
				
				}
			}
		}
		

	}

}
