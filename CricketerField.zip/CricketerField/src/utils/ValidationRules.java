package utils;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.login.CredentialExpiredException;

import com.core.Cricketer;

import custom_exception.CricketerValidationException;

public class ValidationRules {
	
	List<Cricketer> list=new ArrayList<>();
	public static void checkDup(String email,List<Cricketer> list)throws CricketerValidationException
	{
		Cricketer c = new Cricketer(email);
		
		if(list.contains(c))
		{
			throw new CricketerValidationException("Duplicate Data");
		}
		System.out.println("No duplicate Data");
		
	}
	public static Cricketer validateAllInput(String name,int age,String email,String phone,int rating,
			List<Cricketer> list) throws CricketerValidationException {
		
		checkDup(email, list);
		return new Cricketer(name, age, email, phone, rating);
	}
	
	public static void modifyRating(String email,int rating,List<Cricketer> list)
	{
		Cricketer c = new Cricketer(email);
		if(list.contains(c)) {
			int index=list.indexOf(c);
			Cricketer crick=list.get(index);
			crick.setRating(rating);
		}
	}

	
}
