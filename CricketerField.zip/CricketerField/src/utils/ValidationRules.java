package utils;

import com.core.Cricketer;

public class ValidationRules {
	
	public static 
	public static Cricketer validateAllInput(String name,int age,String email,String phone,int rating) {
		
		return new Cricketer(name, age, email, phone, rating);
	}

}
