package custom_exception;

public class CricketerValidationException extends Exception {

	public CricketerValidationException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
