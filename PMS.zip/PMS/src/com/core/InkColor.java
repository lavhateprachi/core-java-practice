package com.core;

public enum InkColor {
    RED,BLUE,BLACK,PINK,GREEN;
}
