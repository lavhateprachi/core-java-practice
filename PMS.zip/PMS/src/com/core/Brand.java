package com.core;

public enum Brand {
    CELLO,PARKER,REYNOLDS;

    @Override
    public String toString()
    {
        return "Name: "+name();
    }
}
