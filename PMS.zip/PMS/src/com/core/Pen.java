package com.core;
import java.time.LocalDate;
public class Pen {

    @Override
    public String toString() {
        return "Pen{" +
                "PID=" + PID +
                ", brand=" + brand +
                ", color='" + color + '\'' +
                ", inkColor=" + inkColor +
                ", material=" + material +
                ", stock=" + stock +
                ", stockUpdateDate=" + stockUpdateDate +
                ", productDate=" + productDate +
                ", price=" + price +
                '}';
    }

    private static int count;
    private int PID;
    private Brand brand;
    private String color;
    private InkColor inkColor;
    private String material;
    private int stock;
    private LocalDate stockUpdateDate;
    private LocalDate productDate;
    private double price;

    private double discount;

    public void setDiscount(double dis)
    {
        discount=dis;
    }
    public double getDiscount()
    {
        return discount;
    }



    static{
        count = 1;
    }

    public Pen(Brand brand, String color, InkColor inkColor, String material,
               int stock, LocalDate stockUpdateDate,
               LocalDate productDate, double price) {
        this.PID=count++;
        this.brand = brand;
        this.color = color;
        this.inkColor = inkColor;
        this.material = material;
        this.stock = stock;
        this.stockUpdateDate = stockUpdateDate;
        this.productDate = productDate;
        this.price = price;

    }

    public void setBrand( Brand brand) {
        this.brand = brand;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setInkColor(InkColor inkColor) {
        this.inkColor = inkColor;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setStockUpdateDate(LocalDate stockUpdateDate) {
        this.stockUpdateDate = stockUpdateDate;
    }

    public void setProductDate(LocalDate productDate) {
        this.productDate = productDate;
    }

    public void setPrice(double price) {
        this.price = price;
    }



    public InkColor getInkColor() {
        return inkColor;
    }

    public String getMaterial() {
        return material;
    }

    public int getStock() {
        return stock;
    }

    public LocalDate getStockUpdateDate() {
        return stockUpdateDate;
    }

    public LocalDate getProductDate() {
        return productDate;
    }

    public double getPrice() {
        return price;
    }


    public Brand getBrand() {
        return brand;
    }

    public int getPID() {
        return PID;
    }
}
