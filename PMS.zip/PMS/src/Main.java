import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import com.core.*;
import populate.*;

import javax.swing.text.html.HTMLDocument;

public class Main {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
            ArrayList<Pen> penArrayList = populateData.populate();
            boolean exit = false;
            while (!exit) {
                System.out.println("\n1.Add Pen \n2.Display Pen \n3.Update Price \n4.Remove Pen \n0.Exit");
                switch (sc.nextInt()) {
                    case 1:
                        System.out.println("Enter Data: brand,color,inkColor," +
                                "material,stock,stockUpdate,productDate,price");

                        Pen p = new Pen(Brand.valueOf(sc.next()), sc.next(), InkColor.valueOf(sc.next()), sc.next(),
                                sc.nextInt(), LocalDate.parse(sc.next()), LocalDate.parse(sc.next()), sc.nextDouble());

                        penArrayList.add(p);
                        System.out.println("Data added Successfully...");
                        break;
                    case 2:
                        penArrayList.forEach(pendata -> System.out.println(pendata));
                        break;


                    case 3:
                        for (Pen penList : penArrayList) {
                            if (penList.getStockUpdateDate().isBefore(LocalDate.now().minusMonths(3))) {


                                penList.setDiscount(20);
                                penList.setPrice(penList.getPrice() -penList.getDiscount());
                            }
                            System.out.println("PID: "+penList.getPID()+" "+"Updated Price: "+penList.getPrice());
                        }
                        System.out.println("Price Updated Successfully....");

                        break;
                    case 4:
                        Iterator<Pen> itr = penArrayList.iterator();
                        while (itr.hasNext()) {
                            Pen cursor = itr.next();
                            // if(itr.next().getStockUpdateDate().isBefore(LocalDate.now().minusMonths(9)))
                            Period period = Period.between(cursor.getStockUpdateDate(), LocalDate.now());
                            int month = period.getMonths();
                            if (month > 9) {
                                itr.remove();
                                System.out.println("Data Removed Successfully...." + cursor.getPID());

                            }
                            //  System.out.println("List After Removal: "+penArrayList);
                        }
                        for (Pen penData : penArrayList)
                            System.out.println(penData);

                        break;

                    case 0:
                        System.exit(0);
                        break;


                }

            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


    }

}

