package populate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.core.Brand;
import com.core.InkColor;
import com.core.Pen;

public class populateData {
    public static ArrayList<Pen> populate()
    {
        ArrayList<Pen> penList=new ArrayList<>();

        penList.add(new Pen(Brand.CELLO,"red", InkColor.BLACK,"Metal",10, LocalDate.parse("2021-12-11"),LocalDate.parse("2020-11-19"),10.0));
        penList.add(new Pen(Brand.REYNOLDS,"black", InkColor.PINK,"Plasic",20, LocalDate.parse("2020-10-01"),LocalDate.parse("2020-11-19"),25.0));
        penList.add(new Pen(Brand.PARKER,"red", InkColor.RED,"Alloy",30, LocalDate.parse("2019-10-11"),LocalDate.parse("2018-10-19"),45.0));
        penList.add(new Pen(Brand.REYNOLDS,"red", InkColor.BLACK,"Metal",50, LocalDate.parse("2019-05-02"),LocalDate.parse("2020-09-10"),10.0));

        penList.add(new Pen(Brand.CELLO,"blue", InkColor.PINK,"Alloy",30, LocalDate.parse("2022-05-02"),LocalDate.parse("2020-09-10"),30.0));

        penList.add(new Pen(Brand.REYNOLDS,"black", InkColor.PINK,"Plastic",30, LocalDate.parse("2023-07-02"),LocalDate.parse("2020-09-10"),30.0));

        return penList;

    }





}
