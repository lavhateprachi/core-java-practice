package com.tester;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.core.Watch;

import utils.ValidationRules;

public class Tester {

	public static void main(String[] args) {
		
		ArrayList <Watch> watchList = new ArrayList<>();
		try(Scanner sc = new Scanner(System.in))
		{
			boolean exit = false;
			
			while(!exit)
			{
				System.out.println("Options: \n1.Add New watch"
						+ "\n2.Update Stock of watch"
						+ "\n3.Set Discount 10% on all watch which are 1 year old"
						+ "\n4.Remove Watches never sold once listed in 18 months"
						+ "\n5.Display"
						+ "\n0.Exit");
				
				System.out.println("Enter Choice: ");
				
				
				try 
				{
						switch(sc.nextInt())
						{
						case 1:
							System.out.println("Enter Watch Details: name, category, brand,shape, style,"
									+ "material,stockQuantity,listingDate,price");
							
							Watch w = ValidationRules.validateAllInputs(sc.next(), sc.next(), 
									sc.next(), sc.next(), sc.next(), sc.next(),
									sc.nextInt(), sc.next(),sc.nextInt(), watchList);
							
							watchList.add(w);
							System.out.println("New watch added Successfully...");
							break;
							
						case 2:
							System.out.println("Enter Watch id and Stock_Quantity: ");
							int watchid=sc.nextInt();
							int quantity=sc.nextInt();
							
							ValidationRules.updateStock(watchid,quantity,watchList);
							System.out.println("Stock Updated Successfully...");
							break;
							
						case 3:
							
							for(Watch watch:watchList)
							{
								if(Period.between(watch.getListingDate(), LocalDate.now()).toTotalMonths()>12)
								{
									watch.setDiscount(10);
									watch.setPrice((int) (watch.getPrice()-(watch.getPrice()*watch.getDiscount()*0.01)));
									System.out.println(watch);
								}
							}
							break;
							
						case 4:
							
							ValidationRules.removeWatch(watchList);
							System.out.println("Watch Removed Successfully...");
							break;
						case 5:
							watchList.forEach(watch -> System.out.println(watch));
							break;
							
						case 0:
							exit=true;
							break;
							
						}
							
							
						
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
		}
	}
}
}