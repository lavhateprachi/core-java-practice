package com.core;

public enum Brand {

	CASIO,TITAN;
}
