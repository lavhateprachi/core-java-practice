package com.core;

public enum Category {

	MEN,WOMEN;
	
	
}
