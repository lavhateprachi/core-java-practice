package com.core;

public enum Style {
	CASUAL,SPORT,WEDDING;

}
