package com.core;

public enum Shape {

	SQUARE,RECTANGLE,ROUND;
}
