package com.core;

import java.time.LocalDate;

public class Watch {
	
	private int watchId;
	private String name;
	private Category category;
	private Brand brand;
	private Shape shape;
	private Style style;
	private Brand_Material brandMaterial;
	private int stockQuantity;
	private LocalDate listingDate;
	private LocalDate updateDate;
	private int price;
	private int discount;
	
	private static int count;
	
	static {
		count=1;
	}

	
	public Watch(String name, Category category, Brand brand, Shape shape, Style style,
			Brand_Material brandMaterial, int stockQuantity, LocalDate listingDate,  int price) {
		super();
		this.watchId = count++;
		this.name = name;
		this.category = category;
		this.brand = brand;
		this.shape = shape;
		this.style = style;
		this.brandMaterial = brandMaterial;
		this.stockQuantity = stockQuantity;
		this.listingDate = listingDate;
		this.updateDate=listingDate;
		this.price = price;	
	}

	
	public int getWatchId() {
		return watchId;
	}

	public void setWatchId(int watchId) {
		this.watchId = watchId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public Shape getShape() {
		return shape;
	}

	public void setShape(Shape shape) {
		this.shape = shape;
	}

	public Style getStyle() {
		return style;
	}

	public void setStyle(Style style) {
		this.style = style;
	}

	public Brand_Material getBrandMaterial() {
		return brandMaterial;
	}

	public void setBrandMaterial(Brand_Material brandMaterial) {
		this.brandMaterial = brandMaterial;
	}

	public int getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public LocalDate getListingDate() {
		return listingDate;
	}

	public void setListingDate(LocalDate listingDate) {
		this.listingDate = listingDate;
	}

	public LocalDate getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDate updateDate) {
		this.updateDate = updateDate;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount=discount;
	}


	public Watch(int id)
	{
		this.watchId=id;
	}
	
	@Override
	public boolean equals(Object o)
	{
		Watch w = (Watch)o;
		return this.watchId == w.watchId;
	}
	
	@Override
	public String toString() {
		return "Watch [watchId=" + watchId + ", name=" + name + ", category=" + category + ", brand=" + brand
				+ ", shape=" + shape + ", style=" + style + ", brandMaterial=" + brandMaterial + ", stockQuantity="
				+ stockQuantity + ", listingDate=" + listingDate + ", updateDate=" + updateDate + ", price=" + price
				+ "]";
	}
	
	
	

}
