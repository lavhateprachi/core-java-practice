package custom_exception;

public class WatchHandlingException extends Exception{
	
	public WatchHandlingException(String message)
	{
		super(message);
	}
}
