package utils;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;

import com.core.Brand;
import com.core.Brand_Material;
import com.core.Category;
import com.core.Shape;
import com.core.Style;
import com.core.Watch;

import custom_exception.WatchHandlingException;

public class ValidationRules {

	public static boolean isValidateId(int id,ArrayList<Watch> watchList) 
	{
		Watch watch = new Watch(id);
		if(watchList.contains(watch))
		{
			return true;
			
		}
		return false;
	}
	
	public static LocalDate parseAndValidateListing(String listingDate)
	{
		return LocalDate.parse(listingDate);
	}
	public static LocalDate parseAndValidateUpdate(String updateDate)
	{
		return LocalDate.parse(updateDate);
	}
	
	public static Category parseCategory(String category)
	{
		return Category.valueOf(category.toUpperCase());
	}
	public static Brand parseBrand(String brand)
	{
		return Brand.valueOf(brand.toUpperCase());
	}
	public static Shape parseShape(String shape)
	{
		return Shape.valueOf(shape.toUpperCase());
	}
	public static Style parseStyle(String style)
	{
		return Style.valueOf(style.toUpperCase());
	}
	public static Brand_Material parseMaterial(String material)
	{
		return Brand_Material.valueOf(material.toUpperCase());
		
	}
	
	public static void updateStock(int id,int quantity,ArrayList<Watch> watchList) 
	{
		watchList.stream().filter(watch->watch.getWatchId()==id).forEach(watch->
		{
			watch.setStockQuantity(quantity);
			watch.setUpdateDate(LocalDate.now());
		});
		
	}
	public static void removeWatch(ArrayList<Watch> watchList) 
	{
		Iterator<Watch> itrWatch=watchList.iterator();
		
		while(itrWatch.hasNext())
		{
			Period period = Period.between(itrWatch.next().getListingDate(), LocalDate.now());
			int month = period.getMonths();
			if(month>18)
			{
				itrWatch.remove();
				System.out.println("Watch Id: "+itrWatch.next().getWatchId());
			}
		}
		
		
	}
	
	public static Watch validateAllInputs(String name, String category, String brand, String shape, String style,
			String brandMaterial, int stockQuantity, String listingDate, int price,
			ArrayList<Watch> watchList)
	{
		LocalDate  listing = parseAndValidateListing(listingDate);
		Category cat =parseCategory(category);
		Brand brand1=parseBrand(brand);
		Style style1=parseStyle(style);
		Shape shape1 =parseShape(shape);
		Brand_Material material=parseMaterial(brandMaterial);
		
		return new Watch(name, cat, brand1,shape1, style1,
			material,stockQuantity, listing,price);
		
	}
	
	
}
