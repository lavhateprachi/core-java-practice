package com.custom_exception;

public class EmployeeValidateException extends Exception{

    public EmployeeValidateException(String str)
    {
        super(str);
    }

}
