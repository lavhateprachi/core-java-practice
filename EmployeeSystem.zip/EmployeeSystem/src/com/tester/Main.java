package com.tester;

import com.core.Employee;
import com.core.FullTimeEmployee;
import com.core.PartTimeEmployee;
import com.utils.EmployeeValidationRules;
import com.utils.CompareDate;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in))
        {
            List<Employee> employeeList = new ArrayList<>();
            boolean exit=false;
            while (!exit)
            {
                System.out.println("Option: " +
                        "\n1.Add Full Time Employee" +
                        "\n2.Add Part Time Employee" +
                        "\n3.Delete Employee by Id" +
                        "\n4.Search By Aadhar" +
                        "\n5.Display " +
                        "\n6.Sort by Joining_Date" +
                        "\n0.Exit");
                System.out.println("Enter Choice: ");
                try
                {
                    switch (sc.nextInt())
                    {
                        case 1:
                            System.out.println("Enter name,joining_date,phone_no,aadhar_no,salary");
                            FullTimeEmployee FTE = EmployeeValidationRules.validateAllInputFTE(sc.next(), sc.next(), sc.next(), sc.next(), sc.nextDouble(), employeeList);
                            employeeList.add(FTE);
                            System.out.println("Full Time Employee Details Added Successfully.....");
                            break;

                        case 2:
                            System.out.println("Enter name,joining_date,phone_no,aadhar_no,hourly_pay");
                            PartTimeEmployee PTE = EmployeeValidationRules.validateAllInputPTE(sc.next(), sc.next(), sc.next(), sc.next(), sc.nextDouble(), employeeList);
                            employeeList.add(PTE);
                            System.out.println("Part Time Employee Details Added Successfully.....");
                            break;

                        case 3:
                            System.out.println("Enter Employee Id: ");
                            int id = sc.nextInt();

                            Iterator<Employee> employeeIterator=employeeList.iterator();
                            while (employeeIterator.hasNext())
                            {
                                if(employeeIterator.next().getEmpId()==id)
                                {
                                    employeeIterator.remove();

                                }
                            }
                            System.out.println(employeeList);
                            break;

                        case 4:
                            System.out.println("Enter Aadhar Number: ");
                            String aadhar= sc.next();
                            employeeList.forEach(employee ->
                            {
                                if(employee.getAadhar_no().equals(aadhar))
                                    System.out.println("Employee Found"+employee.getAadhar_no()+"Details: "+employee);
                            });
                            break;
                        case 5:
                            employeeList.forEach(employee -> System.out.println("Employee Details: "+employee));
                            break;
                        case 6:
                            Collections.sort(employeeList,new CompareDate());
                            for(Employee e:employeeList)
                                System.out.println(e);
                            break;
                        case 0:
                            exit=true;
                            break;
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }

    }
}