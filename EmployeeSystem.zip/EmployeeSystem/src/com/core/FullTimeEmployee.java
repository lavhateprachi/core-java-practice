package com.core;

import java.time.LocalDate;

public class FullTimeEmployee extends Employee{

    private double salary;

    public FullTimeEmployee(String name, LocalDate joining_date, String phone, String aadhar_no,double salary) {
        super(name, joining_date, phone, aadhar_no);
        this.salary=salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "FullTimeEmployee{" +super.toString()+
                "salary=" + salary +
                '}';
    }
}
