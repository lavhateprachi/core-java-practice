package com.core;

import java.awt.image.ReplicateScaleFilter;
import java.time.LocalDate;

public class Employee {

    private static int count;
    private int emp_id;
    private String name;
    private LocalDate joining_date;
    private String phone;
    private String aadhar_no;

    static {
        count=1;
    }

    public Employee(String name, LocalDate joining_date, String phone, String aadhar_no) {
        this.emp_id=count++;
        this.name = name;
        this.joining_date = joining_date;
        this.phone = phone;
        this.aadhar_no = aadhar_no;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getJoining_date() {
        return joining_date;
    }

    public void setJoining_date(LocalDate joining_date) {
        this.joining_date = joining_date;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public int getEmpId() {
        return emp_id;
    }

    public String getAadhar_no() {
        return aadhar_no;
    }

    public void setAadhar_no(String aadhar_no) {
        this.aadhar_no = aadhar_no;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "  Emp_Id: " + emp_id +
                ", Name: " + name + '\'' +
                ", Joining_Date: " + joining_date +
                ", Phone: '" + phone + '\'' +
                ", Aadhar_No: " + aadhar_no + '\'' +
                '}';
    }

    public Employee(int id)
    {
        this.emp_id=id;
    }

    public Employee(String emp)
    {
        this.aadhar_no=emp;
    }

    @Override
    public boolean equals(Object o)
    {
        if(!(o instanceof Employee))
            return false;
        else
            return this.aadhar_no.equals(((Employee) o).getAadhar_no());
    }

}
