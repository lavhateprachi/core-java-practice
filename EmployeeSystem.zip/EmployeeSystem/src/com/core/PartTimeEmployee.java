package com.core;

import java.time.LocalDate;

public class PartTimeEmployee extends Employee{

    private double hourPayment;

    public PartTimeEmployee(String name, LocalDate joining_date, String phone, String aadhar_no,double hrPay) {
        super(name, joining_date, phone, aadhar_no);
        this.hourPayment=hrPay;
    }

    public double getHourPayment() {
        return hourPayment;
    }

    public void setHourPayment(double hourPayment) {
        this.hourPayment = hourPayment;
    }

    @Override
    public String toString() {
        return "PartTimeEmployee{" +super.toString()+
                "hourPayment=" + hourPayment +
                '}';
    }
}
