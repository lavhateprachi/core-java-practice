package com.utils;

import com.core.Employee;

import java.util.Comparator;

public class CompareDate implements Comparator<Employee> {
    @Override
    public int compare(Employee o1, Employee o2) {
        if(o1.getJoining_date().isBefore(o2.getJoining_date()))
            return -1;
        if(o1.getJoining_date().isAfter(o2.getJoining_date()))
            return 1;
        return 0;
    }
}
