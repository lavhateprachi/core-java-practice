package com.utils;

import com.core.Employee;
import com.core.FullTimeEmployee;
import com.core.PartTimeEmployee;
import com.custom_exception.EmployeeValidateException;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeValidationRules {

    public static  LocalDate parseAndValidateDate(String date)
    {
        return LocalDate.parse(date);
    }

    public static boolean validatePhone(String phone) throws EmployeeValidateException
    {
        String regex = "^[7-9]{1}[0-9]{9}$";

        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(phone);

        if(!m.matches())
            throw new EmployeeValidateException("Invalid Phone Number!!!!!" +
                    "Please Enter 10 digits.. Should start with 7/8/9......");
        else
            return true;
    }

    public static boolean validateAadhar(String aadhar) throws EmployeeValidateException
    {
        String regex="^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$";

        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(aadhar);

        if(!m.matches())
            throw new EmployeeValidateException("Invalid Addhar Number!!!!!" +
                    "Please Enter 12 digits.. Should not start with 0/1......");
        else
            return true;
    }

    public static void checkDup(String aadhar, List<Employee> employeeList) throws EmployeeValidateException
    {
        Employee e = new Employee(aadhar);

        if(employeeList.contains(e))
            throw new EmployeeValidateException("Duplicate Employee Entry Not Allowed...");
        else
            System.out.println("Data having Unique Aadhar Number Inserted!!!!!");


    }
    public static FullTimeEmployee validateAllInputFTE(String name, String joining_date,
                                                    String phone, String aadhar_no,
                                                    double salary, List<Employee> employeeList) throws EmployeeValidateException
    {
        LocalDate date = parseAndValidateDate(joining_date);
        checkDup(aadhar_no,employeeList);
        validateAadhar(aadhar_no);
        validatePhone(phone);
        return new FullTimeEmployee(name,date,phone,aadhar_no,salary);
    }
    public static PartTimeEmployee validateAllInputPTE(String name, String joining_date,
                                                    String phone, String aadhar_no,
                                                    double hrPay, List<Employee> employeeList) throws EmployeeValidateException
    {
        LocalDate date = parseAndValidateDate(joining_date);
        checkDup(aadhar_no,employeeList);
        validateAadhar(aadhar_no);
        validatePhone(phone);
        return new PartTimeEmployee(name,date,phone,aadhar_no,hrPay);
    }
}
