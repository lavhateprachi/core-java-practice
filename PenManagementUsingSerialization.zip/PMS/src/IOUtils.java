import java.io.*;
import java.util.ArrayList;
import com.core.*;
public class IOUtils {
    public static void storePenDetails(ArrayList<Pen> penArrayList,String fileName)
    {
        try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName)))
        {
            out.writeObject(penArrayList);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }
    public static ArrayList<Pen> restoreDetails(String filename) throws FileNotFoundException {
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename)))
        {
                return (ArrayList<Pen>) in.readObject();
        }
        catch (Exception e)
        {
            return new ArrayList<>();
        }
    }

}
