package PopulateData;

import com.core.Active;
import com.core.Status;
import com.core.Task;

import java.time.LocalDate;
import java.util.ArrayList;

public class populateData {

    public static ArrayList<Task> populateData() {
        ArrayList<Task> tasks = new ArrayList<>();

        tasks.add(new Task("WakeUp","at 6 a.m", LocalDate.parse("2023-09-12")));
        tasks.add(new Task("Sleep Early","at 10 p.m", LocalDate.parse("2023-01-12")));
        tasks.add(new Task("Read","at least one book a week", LocalDate.parse("2022-10-15")));
        tasks.add(new Task("Write","Daily an Hour", LocalDate.parse("2021-08-31")));
        tasks.add(new Task("Exercise","40 min per day", LocalDate.parse("2023-04-05")));

        return tasks;
    }

}
