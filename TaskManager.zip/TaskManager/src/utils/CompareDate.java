package utils;
import com.core.*;
import java.util.Comparator;

public class CompareDate implements Comparator<Task> {

    @Override
    public int compare(Task o1, Task o2) {
        if(o1.getTaskDate().isBefore(o2.getTaskDate()))
            return -1;
        if(o1.getTaskDate().isAfter(o2.getTaskDate()))
            return 1;

        return 0;
    }
}
