package utils;

import com.core.Active;
import com.core.Status;
import com.core.Task;
import custom_exception.TaskValidationException;

import java.rmi.activation.ActivationID;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

public class ValidationRules {

    List <Task> taskList = new ArrayList<>();

    public static LocalDate parseAndValidateDate(String date){

        return  LocalDate.parse(date);
    }

    public  static Status validateStatus(String status)
    {
        return Status.valueOf(status.toUpperCase());
    }
    public static Active validateActive(String active)
    {
        return  Active.valueOf(active.toUpperCase());
    }

    public static Task validateAllInput(String taskName, String taskDescription, String taskDate,List <Task>taskList)
    {
        LocalDate localDate = parseAndValidateDate(taskDate);
        //Status status1 = validateStatus(status);
        //Active active1=validateActive(active);

        return new Task(taskName, taskDescription, localDate);

    }

    public static void removeTask(int id,List <Task>taskList) throws TaskValidationException
    {

        Task t = new Task(id);

        if(taskList.contains(t)) {
            int index=taskList.indexOf(t);
            taskList.remove(index);

            System.out.println("Removed Successfully...");
        }
        else
            throw new TaskValidationException("Invalid Index...");
    }


}
