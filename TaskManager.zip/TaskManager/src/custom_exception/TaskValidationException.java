package custom_exception;

public class TaskValidationException extends Exception{
    public TaskValidationException(String message) {
        super(message);
    }
}
