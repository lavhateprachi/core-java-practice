import com.core.Active;
import com.core.Status;
import com.core.Task;

import javax.security.sasl.SaslClient;
import java.time.LocalDate;
import java.util.*;

import PopulateData.populateData;
import utils.CompareDate;
import utils.ValidationRules;

public class Main {
    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in))
        {
            ArrayList<Task> taskArrayList = populateData.populateData();
            while (true)
            {
                System.out.println("Option: \n1.Add new task \n2.Delete a task \n3.Update Task Status \n4.Display Pending Task " +
                        "\n5.Display Pending Task for Today \n6.Display task based on sort \n7.Display Tasks \n0.Exit");

                System.out.println("Enter Choice: ");
                switch (sc.nextInt())
                {
                    case 1:
                        System.out.println("Enter Data: taskName, taskDescription, taskDate");
                        Task t=ValidationRules.validateAllInput(sc.next(), sc.next(), sc.next(),taskArrayList);
                        taskArrayList.add(t);
                        System.out.println("Data added successfully....");

                       break;

                    case 2:
                        //System.out.println("Enter task Id: ");
                        int id;
                        //id= sc.nextInt();
                        //ValidationRules.removeTask(id,taskArrayList);

                        Iterator<Task> taskIterator=taskArrayList.iterator();

                        while (taskIterator.hasNext()) {
                            if (Active.FALSE.equals(taskIterator.next().getActive())) {
                                taskIterator.remove();
                            }
                        }
                        break;

                    case 3:
                        System.out.println("Enter task id,status: ");
                        id=sc.nextInt();
                        String status=sc.next();

                        t=new Task(id);

                        if(taskArrayList.contains(t))
                        {
                            int index=taskArrayList.indexOf(t);
                            Task task = taskArrayList.get(index);

                            task.setStatus(Status.valueOf(status.toUpperCase()));

                            System.out.println("Task Updated Successfully...."+task.getTaskId()+"Status: "+task.getStatus());
                        }
                        break;
                    case 4:
                        Status status1=Status.PENDING;
                        System.out.println("Display Pending tasks OnLY....");
                        taskArrayList.forEach(task -> {
                            if(status1.equals(task.getStatus()))
                            {
                                System.out.println(task);
                            }

                        });

                        break;
                    case 5:
                        taskArrayList.forEach(task -> {
                            if(task.getStatus().equals(Status.PENDING))
                            {
                                if(task.getTaskDate().getDayOfMonth()==LocalDate.now().getDayOfMonth())
                                {
                                    System.out.println(task);
                                }
                            }
                        });
                        break;
                    case 6:

                        System.out.println("Sort Data As Per TaskDate: ");
                        Collections.sort(taskArrayList,new CompareDate());
                        taskArrayList.forEach(task -> System.out.println(task));
                        break;

                    case  7:
                        taskArrayList.forEach(task -> System.out.println(task));
                        break;
                    case 8:
                        System.out.println("Enter id to update Active state: ");
                        id= sc.nextInt();

                        t=new Task(id);

                        if(taskArrayList.contains(t))
                        {
                            int index=taskArrayList.indexOf(t);
                            Task task = taskArrayList.get(index);
                            task.setActive(Active.valueOf(sc.next()));
                            System.out.println("Active Status Updated Successfully...");
                        }

                        break;
                    case 0:
                        System.exit(0);
                        break;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}