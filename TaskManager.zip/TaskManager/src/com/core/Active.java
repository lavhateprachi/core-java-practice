package com.core;

public enum Active {
    TRUE,FALSE;

    @Override
    public String toString() {
        return "Name: "+name();
    }
}
