package com.core;

import javax.swing.*;
import java.time.LocalDate;

public class Task {
    private static int count;
    private int taskId;
    private String taskName;
    private String taskDescription;
    private LocalDate taskDate;
    private Status status;
    private Active active;


    static {
        count=1;
    }

    public Task(String taskName, String taskDescription, LocalDate taskDate) {

        this.taskId = count++;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.taskDate = taskDate;
        this.status = Status.PENDING;
        this.active = Active.TRUE;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public LocalDate getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(LocalDate taskDate) {
        this.taskDate = taskDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Active getActive() {
        return active;
    }

    public void setActive(Active active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId=" + taskId +
                ", taskName='" + taskName + '\'' +
                ", taskDescription='" + taskDescription + '\'' +
                ", taskDate=" + taskDate +
                ", status=" + status +
                ", active=" + active +
                '}';
    }

   public Task(int id)
   {
       taskId=id;
   }

   public boolean equals(Object t)
   {
       return this.taskId == ((Task)t).taskId;
   }



}

