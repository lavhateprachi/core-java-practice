package com.core;

import java.util.Comparator;

public class compareRating implements Comparator<Cricketer> {


    @Override
    public int compare(Cricketer o1, Cricketer o2) {

        if(o1.getRating()<o2.getRating())
            return -1;
        if(o1.getRating()>o2.getRating())
            return 1;
        return 0;
    }
}
