package com.tester;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import utils.*;
import com.core.*;

import custom_exception.CricketerValidationException;

public class CricketerField {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Scanner sc = new Scanner(System.in))
		{
			ArrayList<Cricketer> list = new ArrayList<>();
			while(true)
			{
				System.out.println("Option: \n1.Add Cricketer Data"
						+ "\n2.Modify Rating"
						+ "\n3.Search By Name"
						+ "\n4.Display"
						+ "\n5.Sort by Rating"
						+ "\n0.Exit");
				
				System.out.println("Enter Choice: ");
				switch (sc.nextInt()) {
				case 1:

						System.out.println("Enter name,age,email,phone,rating(out of 10):");
						Cricketer c = ValidationRules.validateAllInput(sc.next(), sc.nextInt(),
								sc.next(), sc.next(), sc.nextInt(), list);

						list.add(c);

					System.out.println("data added successfully...");
					break;
					
				case 2:
					System.out.println("Enter Email : ");
					String email=sc.next();
					System.out.println("Enter ratings: ");
					int rating=sc.nextInt();
					ValidationRules.modifyRating(email, rating, list);
					
					System.out.println("Ratings modified successfully...");
					break;
				case 3:
					System.out.println("Enter name to search: ");
					String name = sc.next();
					list.forEach(dataName -> 
					{
						if(dataName.getName().equals(name))
						{
							System.out.println("Data found by Name"+ dataName);
						}
						
					});
				
					break;
				case 4:
					list.forEach(cricketer -> System.out.println(cricketer));
					break;

					case 5:
						Collections.sort(list,new compareRating());
						list.forEach(cricketer -> System.out.println(cricketer));
						break;
				case 0:
					System.exit(0);
					break;
				
				}
			}
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		

	}

}
