package utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.security.auth.login.CredentialExpiredException;

import com.core.Cricketer;

import custom_exception.CricketerValidationException;

public class ValidationRules {
	
	List<Cricketer> list=new ArrayList<>();
	public static void checkDup(String email,List<Cricketer> list)throws CricketerValidationException
	{
		Cricketer c = new Cricketer(email);
		
		if(list.contains(c))
		{
			throw new CricketerValidationException("Duplicate Data");
		}
		System.out.println("No duplicate Data");
		
	}

	
	public static void modifyRating(String email,int rating,List<Cricketer> list)
	{
		Cricketer c = new Cricketer(email);
		if(list.contains(c)) {
			int index=list.indexOf(c);
			Cricketer crick=list.get(index);
			crick.setRating(rating);
		}
	}

	public static int validateRating(int rating) throws CricketerValidationException
	{
		if(rating>10)
			throw new CricketerValidationException("Rating not in Range.. Please rate in between 1 to 10");
		else
			return rating;
	}

	public static boolean validatePhone(String phone) throws CricketerValidationException
	{
		String regex = "^[7-9]{1}[0-9]{9}$";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(phone);

		if(!m.matches())
			throw new CricketerValidationException("You entered invalid phone number..." +
					"Phone number should contain 10 digits starting with 7/8/9...");
		else
			return true;
	}

	public static Cricketer validateAllInput(String name,int age,String email,String phone,int rating,
											 List<Cricketer> list) throws CricketerValidationException
	{
		validatePhone(phone);
		checkDup(email, list);
		int rate = validateRating(rating);
		return new Cricketer(name, age, email, phone, rate);
	}

	
}
