package com.core;

import java.time.LocalDate;

public class Bank implements Comparable<Bank>
{

    private LocalDate transactionDate;
    private String narration;
    private double withdraw;
    private double deposit;

    public Bank(LocalDate transactionDate, String narration, double withdraw, double deposit) {
        this.transactionDate = transactionDate;
        this.narration = narration;
        this.withdraw = withdraw;
        this.deposit = deposit;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDate transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getNarration() {
        return narration;
    }

    public void setNarration(String narration) {
        this.narration = narration;
    }

    public double getWithdraw() {
        return withdraw;
    }

    public void setWithdraw(double withdraw) {
        this.withdraw = withdraw;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "transactionDate=" + transactionDate +
                ", narration='" + narration + '\'' +
                ", withdraw=" + withdraw +
                ", deposit=" + deposit +
                '}';
    }

    @Override
    public int compareTo(Bank o) {
        return this.getNarration().compareTo(o.getNarration());
    }
}
