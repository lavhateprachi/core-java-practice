import com.core.Bank;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.lang.String;



public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Bank> bankArrayList = new ArrayList<Bank>();

        try(Scanner sc = new Scanner(System.in);
            BufferedReader br = new BufferedReader(new FileReader("E:\\DotDelete\\Desktop\\BankDetails.txt") );
            BufferedWriter bw = new BufferedWriter(new FileWriter("E:\\DotDelete\\Desktop\\SortDetails.txt")))
        {
            double sumDeposit=0;
            double maxDeposit;
            double shoppingExpense= 0;
            LocalDate date;

            br.readLine();

            br.lines().forEach(bank->
            {

                //System.out.println(bank);
                String line=bank;

                String arr[]=line.split(",");

                String dateString = arr[0];

                int day = Integer.parseInt(dateString.substring(0,2));
                int month = Integer.parseInt(dateString.substring(3,5));
                int year = Integer.parseInt(dateString.substring(6,10));

                //System.out.println(dateString);

                Bank b1 = new Bank(LocalDate.of(year,month,day),arr[1],Double.parseDouble(arr[2]),Double.parseDouble(arr[3]));
                bankArrayList.add(b1);

            });

            boolean exit=false;
            while (!exit)
            {
                System.out.println("Option: \n1.Display Bank Details" +
                        "\n2.Sum Of Deposits" +
                        "\n3.Max Deposit" +
                        "\n4.Min Deposit" +
                        "\n5.Shopping Expenses" +
                        "\n6.Date on which MaxAmountWithdrawn" +
                        "\n7.Average Deposit" +
                        "\n8.Sort " +
                        "\n0.Exit");
                System.out.println("Enter Choice: ");

                switch (sc.nextInt())
                {
                    case 1:
                        for(Bank b:bankArrayList)
                            System.out.println(b);
                        break;

                    case 2:
                        for (Bank bank:bankArrayList)
                        {
                            sumDeposit+=bank.getDeposit();
                        }
                        System.out.println("Total Deposit: "+sumDeposit);

                        break;

                    case 3:
                       Bank b= bankArrayList.stream().max((b1,b2)->((Double)b1.getDeposit()).compareTo(b2.getDeposit())).orElseThrow();
                       System.out.println("Max Deposit: "+b.getDeposit());
                       break;
                    case 4:
                        b = bankArrayList.stream().min((b1,b2)->((Double)b1.getDeposit()).compareTo(b2.getDeposit())).orElseThrow();
                        System.out.println("Min Deposit: "+b.getDeposit());
                        break;
                    case 5:

                        for(Bank bank: bankArrayList)
                        {
                            if(bank.getNarration().equals("Shopping"))
                            {
                                shoppingExpense+=bank.getWithdraw();
                            }
                        }
                        System.out.println("Shopping Expenses: "+shoppingExpense);

                        break;
                    case 6:
                        b= bankArrayList.stream().max((b1,b2)->((Double)b1.getDeposit()).compareTo(b2.getDeposit())).orElseThrow();
                        System.out.println("Max Deposit: "+b.getDeposit()+"Date: "+b.getTransactionDate());
                        break;
                    case 7:

                       double bank = bankArrayList.stream().mapToDouble(deposit->deposit.getDeposit()).average().orElseThrow();
                       System.out.println("Average Deposit: "+bank);

                        break;

                    case 8:
                        System.out.println("Sorted Data:");
                        Collections.sort(bankArrayList);
                        for(Bank bank1:bankArrayList) {
                            System.out.println(bank1);
                            bw.write(String.valueOf(bank1));
                            bw.write("\n");
                            bw.flush();
                        }

                        break;
                    case 0:
                        exit=true;
                        break;
                }
            }

        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}