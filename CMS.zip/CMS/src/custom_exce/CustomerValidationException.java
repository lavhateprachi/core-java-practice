package custom_exce;

public class CustomerValidationException extends Exception {

	public CustomerValidationException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
	
}
