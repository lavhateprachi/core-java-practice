package com.compare;

import java.util.Comparator;

import com.core.Customer;

public class CustomerCompare implements Comparator<Customer> {

	@Override
	public int compare(Customer c1, Customer c2) {
		System.out.println("In compare");
		int indexLast=c1.getLastname().compareTo(c2.getLastname());
		if(indexLast<0)
			return -1;
		if(indexLast>0)
			return 1;
		return 0;
	}

}
