package com.core;

import java.time.LocalDate;

public class Customer implements Comparable<Customer>{

	static int counter;
	private int cust_id;
	private String firstname;
	private String lastname;
	private String email;
	private String password;
	private double regAmount;
	
	private LocalDate dob;
	private static LocalDate regdate;
	private LocalDate subDate;
	ServicePlan plan;
	
	
	static 
	{
		regdate=LocalDate.now();
		counter=1;
	}
	public Customer(){

	}



	public Customer(String firstname, String lastname, String email, String password, double regAmount,
			LocalDate dob,LocalDate subDate,ServicePlan plan) {
		super();
		this.cust_id = counter++;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.password = password;
		this.regAmount = regAmount;
		this.dob = dob;
		this.subDate=subDate;
		this.plan = plan;
	}
	
	public Customer(String email)
	{
		super();
		this.email=email;
	}
	public Customer(String email,String pass)
	{
		super();
		this.email=email;
		this.password=pass;
	}

	
	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", firstname=" + firstname + ", lastname=" + lastname + ", email="
				+ email + ", password=" + password + ", regAmount=" + regAmount + ", dob=" + dob + ", subDate="
				+ subDate + ", plan=" + plan + "]";
	}

	public boolean equals(Object o)
	{
		System.out.println("In Equals Method...");
		if(o instanceof Customer)
		{
			Customer anotherCust=(Customer)o;
			return this.email.equals(anotherCust.email);
		}
		return false;
		
	}

	/**
	 * @return the cust_id
	 */
	public int getCust_id() {
		return cust_id;
	}

	/**
	 * @param cust_id the cust_id to set
	 */
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the regAmount
	 */
	public double getRegAmount() {
		return regAmount;
	}

	/**
	 * @param regAmount the regAmount to set
	 */
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}

	/**
	 * @return the dob
	 */
	public LocalDate getDob() {
		return dob;
	}
	public LocalDate getSubDate() {
		return subDate;
	}
	public LocalDate getRegDate() {
		return regdate;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	/**
	 * @return the plan
	 */
	public ServicePlan getPlan() {
		return plan;
	}

	/**
	 * @param plan the plan to set
	 */
	public void setPlan(ServicePlan plan) {
		this.plan = plan;
	}

	@Override
	public int compareTo(Customer o) {
		// TODO Auto-generated method stub
		return this.email.compareTo(o.email);
	}
}