package com.core;

import java.time.LocalDate;

public class Tape extends Publication{

    private int playingTime;

    public Tape(String title, int price, LocalDate publishDate, int rating, int playingTime) {
        super(title, price, publishDate, rating);
        this.playingTime = playingTime;
    }
    public int getPlayingTime() {
        return playingTime;
    }

    public void setPlayingTime(int playingTime) {
        this.playingTime = playingTime;
    }

    @Override
    public String toString() {
        return "Tape{" +super.toString()+
                "playingTime=" + playingTime +
                '}';
    }
}
