package custom_exception;

public class PublicationValidationException extends Exception{

    public PublicationValidationException(String message)
    {
        super(message);
    }
}
