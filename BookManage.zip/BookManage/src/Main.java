import com.core.Book;
import com.core.Publication;
import com.core.Tape;
import utils.CompareDate;
import utils.ValidationRules;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        List<Publication> publications=new ArrayList<Publication>();

        try(Scanner sc = new Scanner(System.in);
        BufferedWriter bw = new BufferedWriter(new FileWriter("Publication.txt"));)
        {
            boolean exit=false;
            while (!exit)
            {
                System.out.println("Option: \n1.Add new Book" +
                        "\n2.Add New tape" +
                        "\n3.List Book in Desc Order" +
                        "\n4.List top 5 publication " +
                        "\n5.Remove publication 5 year old" +
                        "\n6.Display All" +
                        "\n0.Exit");
                System.out.println("Enter Choice: ");
                try {
                    switch (sc.nextInt()) {
                        case 1:
                            System.out.println("Enter Book Details: Title | Price | PublishDate | Rating | Page Count");
                            Book b = ValidationRules.validateBook(sc.next(), sc.nextInt(), sc.next(), sc.nextInt(), sc.nextInt(), publications);
                            publications.add(b);
                            System.out.println("Book Inserted Successfully...");
                            break;

                        case 2:
                            System.out.println("Enter Tape Details: Title | Price | PublishDate | Rating | Play Time");
                            Tape t = ValidationRules.validateTape(sc.next(), sc.nextInt(), sc.next(), sc.nextInt(), sc.nextInt(), publications);
                            publications.add(t);
                            System.out.println("Tape Inserted Successfully...");
                            break;

                        case 3:
//                            publications
//                                    .stream()
//                                    .filter(publication -> publication instanceof Book)
//                                    .map(publication -> (Book)publication)
//                                    .sorted(((o1, o2) -> o2.getPublishDate().compareTo(o1.getPublishDate())))
//                                    .forEach(publication ->System.out.println(publication) );

                            Collections.sort(publications,new CompareDate());
                            publications.forEach(publication -> System.out.println(publication));
                            break;

                        case 4:
                            publications.stream().sorted(((o1, o2) -> ((Integer)o2.getRating()).compareTo(o1.getRating())))
                                    .limit(5)
                                    .forEach(publication -> System.out.println(publication));
                            break;
                        case 5:
                            Iterator<Publication> itr = publications.iterator();
                            while (itr.hasNext())
                            {
                                Period period=Period.between(itr.next().getPublishDate(), LocalDate.now());
                                int year = period.getYears();
                                if(year==5) {
                                    itr.remove();
                                    System.out.println("Removed Publication: "+itr.next().getId()+"Name: "+itr.next().getTitle());
                                }
                            }
                            break;
                        case 6:
                            for(Publication publication:publications)
                                System.out.println(publication);
                            break;
                        case 0:
                            for (Publication publication:publications)
                            {
                                bw.write(String.valueOf(publication));
                                bw.write("\n");
                                bw.flush();
                            }
                            exit=true;
                            break;
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }//.filter(publication -> publication instanceof Book)
        catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}