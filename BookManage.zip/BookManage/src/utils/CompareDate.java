package utils;

import com.core.Book;
import com.core.Publication;

import java.util.Comparator;

public class CompareDate implements Comparator<Publication> {
    @Override
    public int compare(Publication o1, Publication o2) {

            if(o1 instanceof Book && o2 instanceof Book)
            {
                Book b1 = (Book) o1;
                Book b2 =(Book) o2;
                return b2.getPublishDate().compareTo(b1.getPublishDate());
            }
            return -1;
    }
}
