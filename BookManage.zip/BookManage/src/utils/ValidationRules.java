package utils;
import com.core.Book;
import com.core.Publication;
import com.core.Tape;
import custom_exception.PublicationValidationException;
import java.time.LocalDate;
import java.util.List;

public class ValidationRules {

    public static LocalDate parseValidateDate(String date)
    {
        return LocalDate.parse(date);
    }
    public static int checkRating(int rating)throws PublicationValidationException
    {
        if(rating>10 && rating<1)
            throw new PublicationValidationException("Invalid Range.. Provide in Between 1-10");
        else
            return rating;


    }

    public static Book validateBook(String title, int price, String publish, int rating, int pageCount, List<Publication> publications) throws PublicationValidationException {
        LocalDate publishDate=parseValidateDate(publish);
        int rate=checkRating(rating);
        return new Book(title,price,publishDate, rate,  pageCount);
    }
    public static Tape validateTape(String title, int price, String publish, int rating, int playTime, List<Publication> publications) throws PublicationValidationException {
        LocalDate publishDate=parseValidateDate(publish);
        int rate=checkRating(rating);
        return new Tape(title,price,publishDate, rate,  playTime);
    }

}
